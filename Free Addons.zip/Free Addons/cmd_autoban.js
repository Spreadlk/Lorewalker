const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const yaml = require('js-yaml');
const fs = require('fs');
const config = yaml.load(fs.readFileSync('config.yml', 'utf8'));

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

const LOG_CHANNEL_ID = 'CHANNEL_ID';
const BYPASS_ROLE_IDS = ["ROLE_ID", "ADD_MULTIPLE"];

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.guild) {
    return;
  }

  if (message.member.roles.cache.some((role) => BYPASS_ROLE_IDS.includes(role.id))) {
    return;
  }

  if (containsInviteLink(message.content)) {
    try {
      const inviteCode = getInviteCode(message.content);
      const invite = await client.fetchInvite(inviteCode).catch(() => null);

      // Check if the invite is from the current server
      if (invite && invite.guild && invite.guild.id === message.guild.id) {
        return;
      }

      // Send DM to the user before banning
      await message.author.send({
        content: `> You've been banned from **${message.guild.name}**.\n> **Reason**: Discord invite link`,
      });

      await message.delete();

      const member = await message.guild.members.fetch({ user: message.author, force: true });
      await member.ban({ reason: 'Discord invite link' });

      const embed = new EmbedBuilder()
        .setTitle('⚠️ BAN')
        .setDescription(`> **${message.author.tag} / ${message.author} was banned**.\n> **Reason**: Discord invite link`)
        .setThumbnail('https://imgur.com/Qcdj7In.png')
        .setImage('https://c.tenor.com/qMcJnxZFWgQAAAAC/tenor.gif')
        .setColor('#FF0000');

      const channel = message.channel;
      await channel.send({ embeds: [embed] });

      const logChannel = message.guild.channels.cache.get(LOG_CHANNEL_ID);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('⚠️ User banned')
          .setDescription(`> **${message.author.tag} / ${message.author} was banned**.\n> **Reason**: Discord invite link\n\n> **Content**: \`\`${message.content}\`\``)
          .setThumbnail('https://imgur.com/Qcdj7In.png')
          .setImage('https://c.tenor.com/qMcJnxZFWgQAAAAC/tenor.gif')
          .setColor('#FF0000');

        await logChannel.send({ embeds: [logEmbed] });
      }
    } catch (error) {
      if (error.code === 50007) {
        console.error('Cannot send a message to this user (DMs disabled or blocked).');
      } else {
        console.error('Error banning user:', error);
      }
    }
  }
});

function containsInviteLink(content) {
  const inviteLinkRegex = /(discord\.gg\/[a-zA-Z0-9]+|discordapp\.com\/invite\/[a-zA-Z0-9]+)/;
  return inviteLinkRegex.test(content);
}

function getInviteCode(content) {
  const inviteCodeRegex = /(discord\.gg\/|discordapp\.com\/invite\/)([a-zA-Z0-9]+)/;
  const match = content.match(inviteCodeRegex);
  return match ? match[2] : null;
}

client.login(config.BotToken);