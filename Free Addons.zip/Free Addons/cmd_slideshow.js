const {
    WebhookClient,
    EmbedBuilder
} = require('discord.js');
const fs = require('fs');
const yaml = require('js-yaml');
const path = require('path');

class Slideshow {
    constructor() {
        this.webhooks = new Map();
        this.lastMessageIds = {};
        this.ensureConfigExists();
        this.config = this.loadConfig();
        this.loadLastMessageIds();
    }

    ensureConfigExists() {
        const configPath = './config.yml';
        const defaultConfigString = `

webhooks:
  - url: "https://discord.com/api/webhooks/your_webhook_id_1/your_webhook_token_1"
    embeds:
      - title: "Embed Title 1 for Webhook 1"
        description: "Description for Embed 1"
        images:
          - "https://cdn-icons-png.flaticon.com/512/2815/2815428.png"
          - "https://cdn-icons-png.flaticon.com/512/3349/3349798.png"
        footer: "Footer for Embed 1"
        interval: "5s"  # Rotates every 5 seconds

  - url: "https://discord.com/api/webhooks/your_webhook_id_2/your_webhook_token_2"
    embeds:
      - title: "Embed Title 2 for Webhook 2"
        description: "Description for Embed 2"
        images:
          - "http://example.com/image1.jpg"
          - "http://example.com/image2.jpg"
        footer: "Footer for Embed 2"
        interval: "1m 15s"  # Rotates every 1 minute 15 seconds`;

        if (fs.existsSync(configPath)) {
            const content = fs.readFileSync(configPath, 'utf8');
            if (!content.includes('webhooks:')) {
                fs.appendFileSync(configPath, defaultConfigString);
            }
        } else {
            fs.writeFileSync(configPath, defaultConfigString.trim());
        }
    }

    loadConfig() {
        const configPath = './config.yml';
        const config = yaml.load(fs.readFileSync(configPath, 'utf8'));

        for (const webhookConfig of config.webhooks) {
            if (this.isPlaceholderUrl(webhookConfig.url)) {
                console.log('Skipping webhook with placeholder URL:', webhookConfig.url);
                continue;
            }

            try {
                const {
                    id,
                    token
                } = this.parseWebhookUrl(webhookConfig.url);
                const webhookClient = new WebhookClient({
                    id: id,
                    token: token
                });
                for (const embedConfig of webhookConfig.embeds) {
                    this.scheduleEmbedRotation(webhookClient, embedConfig);
                }
            } catch (error) {
                console.error('Error processing webhook URL:', error.message);
            }
        }
    }

    isPlaceholderUrl(url) {
        return url.includes('your_webhook_id') || url.includes('your_webhook_token');
    }

    parseWebhookUrl(url) {
        const match = url.match(/\/api\/webhooks\/(\d+)\/([\w-]+)/);
        if (match && match.length >= 3) {
            const id = match[1];
            const token = match[2];
            return {
                id,
                token
            };
        } else {
            throw new Error('Invalid webhook URL');
        }
    }

    scheduleEmbedRotation(webhookClient, embedConfig) {
        const intervalMs = this.parseInterval(embedConfig.interval);
        const rotationFunction = () => {
            this.rotateEmbed(webhookClient, embedConfig);
            setTimeout(rotationFunction, intervalMs);
        };
        setTimeout(rotationFunction, intervalMs);
    }

    parseInterval(intervalString) {
        let totalMilliseconds = 0;
        const parts = intervalString.match(/(\d+)([smh])/g);
        if (parts) {
            for (const part of parts) {
                const value = parseInt(part.match(/\d+/)[0], 10);
                const unit = part.match(/[smh]/)[0];

                switch (unit) {
                    case 's':
                        totalMilliseconds += value * 1000;
                        break; // seconds
                    case 'm':
                        totalMilliseconds += value * 60000;
                        break; // minutes
                    case 'h':
                        totalMilliseconds += value * 3600000;
                        break; // hours
                }
            }
        }

        return totalMilliseconds;
    }

    async rotateEmbed(webhookClient, embedConfig) {
        const embed = this.createEmbed(embedConfig);
        const webhookId = webhookClient.id;
        const lastMessageId = this.lastMessageIds[webhookId];

        try {
            if (lastMessageId) {
                await webhookClient.editMessage(lastMessageId, {
                    embeds: [embed]
                });
            } else {
                const sentMessage = await webhookClient.send({
                    embeds: [embed]
                });
                this.lastMessageIds[webhookId] = sentMessage.id;
            }
        } catch (error) {
            if (error.code === 10008) {
                const sentMessage = await webhookClient.send({
                    embeds: [embed]
                });
                this.lastMessageIds[webhookId] = sentMessage.id;
            } else {
                console.error('Error updating the embed:', error);
            }
        }

        this.updateImageIndex(embedConfig);
        this.saveLastMessageIds();
    }

    createEmbed(embedConfig) {
        const currentImageIndex = this.getCurrentImageIndex(embedConfig);
        const embed = new EmbedBuilder()
            .setTitle(embedConfig.title)
            .setDescription(embedConfig.description)
            .setImage(embedConfig.images[currentImageIndex])
            .setFooter({
                text: embedConfig.footer
            });
        return embed;
    }

    getCurrentImageIndex(embedConfig) {
        const embedId = this.getEmbedId(embedConfig);
        const currentIndex = this.webhooks.get(embedId) || 0;
        return currentIndex;
    }

    updateImageIndex(embedConfig) {
        const embedId = this.getEmbedId(embedConfig);
        let currentIndex = this.getCurrentImageIndex(embedConfig);
        currentIndex = (currentIndex + 1) % embedConfig.images.length;
        this.webhooks.set(embedId, currentIndex);
    }

    getEmbedId(embedConfig) {
        return embedConfig.title + embedConfig.description;
    }

    saveLastMessageIds() {
        const filePath = path.join(__dirname, 'lastMessageIds.json');
        fs.writeFileSync(filePath, JSON.stringify(this.lastMessageIds));
    }

    loadLastMessageIds() {
        const filePath = path.join(__dirname, 'lastMessageIds.json');
        if (fs.existsSync(filePath)) {
            this.lastMessageIds = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        }
    }
}

const slideshow = new Slideshow();