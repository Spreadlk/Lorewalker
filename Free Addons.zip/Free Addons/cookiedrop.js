const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const yaml = require('js-yaml');
const { REST } = require('@discordjs/rest');
const fs = require('fs');
const config = yaml.load(fs.readFileSync('config.yml', 'utf8'));

const allowedChannelId = 'ALLOWED_CHANNEL_ID'; // Replace with your channel ID

const cooldownTime = 5 * 60 * 1000; // 5 minutes cooldown after a new event can be re-triggered

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
});

let lastCookieDropTime = 0;
let claimingUser = null;
let cookieMessageId = null;

client.on('messageCreate', (message) => {
  if (message.author.bot || !message.guild || message.channel.id !== allowedChannelId) return;

  const currentTime = Date.now();

  if (currentTime - lastCookieDropTime > cooldownTime) {
    const randomNumber = Math.floor(Math.random() * 100); // MAXIMUM RANGE OF MESSAGES FOR WHEN THE EVENT WILL TRIGGER, IF YOU MAKE IT TO 10, THEN THE EVENT WILL TRIGGER IN A RANGE OF 1 TO 10 MESSAGES. DEFAULT IS FROM 1 TO 100 A RANDOM NUMBER OF MESSAGES

    if (randomNumber < 5) {
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle('🍪 Cookies Drop!')
        .setDescription(`Type \`cookie claim\` to claim your cookies!`);
   embed.setFooter({ text: `Event Drop | Stellar Bot`})
   embed.setTimestamp()

      message.channel.send({ embeds: [embed] }).then(sentMessage => {
        cookieMessageId = sentMessage.id;

        const claimingTimeout = setTimeout(() => {
          if (claimingUser === null && cookieMessageId) {
            embed.setDescription('No one claimed the cookies 😔');
            sentMessage.edit({ embeds: [embed] });

            claimingUser = null;
            lastCookieDropTime = currentTime;
            cookieMessageId = null;
          }
        }, 15 * 1000); // THIS IS THE TIME BEFORE THE MESSAGE EMBED WILL CHANGE INTO "NO ONE CLAIMED THE COOKIES" AND COOKIES WILL BECOME UNCLAIMABLE
      });

      lastCookieDropTime = currentTime;
    }
  }

  const isClaimCommand = message.content.toLowerCase() === 'cookie claim';
  const isSpamClaim = message.content.toLowerCase() === 'claim';

  if ((isClaimCommand || isSpamClaim) && !message.author.bot && claimingUser === null && cookieMessageId) {
    claimingUser = message.author.id;

    const claimedEmbed = new EmbedBuilder()
      .setColor('#FFD700')
      .setDescription(`🍪 Cookies claimed by <@${message.author.id}>!`);
      claimedEmbed.setFooter({ text: `Event Drop | Stellar Bot`})
      claimedEmbed.setTimestamp()

    message.channel.messages.fetch(cookieMessageId).then((botMessage) => {
      botMessage.edit({ embeds: [claimedEmbed] });

      lastCookieDropTime = currentTime;
      claimingUser = null;
      cookieMessageId = null;
    });

    message.reply('🍪 Yum! You claimed your cookies!');
  }
});

client.login(config.BotToken);