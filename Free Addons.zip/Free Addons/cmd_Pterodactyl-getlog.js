const { SlashCommandBuilder } = require('discord.js');
const axios = require('axios');

const PTERODACTYL_API_KEY = 'your api key';
const PTERODACTYL_PANEL_URL = 'https://your.host.net'; // https://mc.bloom.host for example

const serverIdMap = {
    'Proxy': 'serverid1',
    'Hub': 'serverid2'
};

// Allowed role IDs
const allowedRoles = ['RoleID1', 'RoleID2'];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('getlog')
        .setDescription('Fetches the latest logs from the specified server.')
        .addStringOption(option =>
            option.setName('server')
                .setDescription('The server to fetch logs from')
                .setRequired(true)
                .addChoices(
                    { name: 'Proxy', value: 'Proxy' },
                    { name: 'Hub', value: 'Hub' }
                )),
    async execute(interaction) {
        const memberRoles = interaction.member.roles.cache;
        if (!memberRoles.some(role => allowedRoles.includes(role.id))) {
            await interaction.reply({ content: "You do not have permission to use this command.", ephemeral: true });
            return;
        }

        const serverName = interaction.options.getString('server');
        const serverId = serverIdMap[serverName];

        if (!serverId) {
            await interaction.reply({ content: `Server not recognized: ${serverName}`, ephemeral: true });
            return;
        }

        try {
            const urlResponse = await axios.get(`${PTERODACTYL_PANEL_URL}/api/client/servers/${serverId}/files/download?file=%2Flogs/latest.log`, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept-Encoding': '*',
                    'Authorization': `Bearer ${PTERODACTYL_API_KEY}`
                }
            });

            const signedUrl = urlResponse.data.attributes.url;

            try {
                const fileResponse = await axios.get(signedUrl, {
                    responseType: 'arraybuffer',
                });

                const fileData = fileResponse.data;

                await interaction.reply({ files: [{ attachment: Buffer.from(fileData), name: 'latest.log' }], ephemeral: true });

            } catch (error) {
                console.error("Error downloading or sending the file: ", error);
                await interaction.reply({ content: 'Failed to download or send the logs.', ephemeral: true });
            }

        } catch (error) {
            console.error("Error during API Request: ", error);
            await interaction.reply({ content: 'Failed to retrieve the logs.', ephemeral: true });
        }
    }
};
