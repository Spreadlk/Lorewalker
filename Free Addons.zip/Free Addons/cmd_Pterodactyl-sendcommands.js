const { SlashCommandBuilder } = require('discord.js');
const axios = require('axios');

const PTERODACTYL_API_KEY = 'your api key';
const PTERODACTYL_PANEL_URL = 'https://your.host.net'; // https://mc.bloom.host for example

const serverIdMap = {
    'Proxy': 'ServerID1',
    'Hub': 'ServerID2'
};

// Allowed role IDs
const allowedRoles = ['RoleID1', 'RoleID2'];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sendcommand')
        .setDescription('Sends a command to the specified server.')
        .addStringOption(option =>
            option.setName('command')
                .setDescription('The command to send to the server')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('server')
                .setDescription('The server to send the command to')
                .setRequired(true)
                .addChoices(
                    { name: 'Proxy', value: 'Proxy' },
                    { name: 'Hub', value: 'Hub' }
                )),
    async execute(interaction) {
        const memberRoles = interaction.member.roles.cache;
        if (!memberRoles.some(role => allowedRoles.includes(role.id))) {
            await interaction.reply({ content: "You do not have permission to use this command.", ephemeral: true });
            return;
        }

        const serverName = interaction.options.getString('server');
        const serverId = serverIdMap[serverName];
        const commandToSend = interaction.options.getString('command');

        if (!serverId) {
            await interaction.reply({ content: `Server not recognized: ${serverName}`, ephemeral: true });
            return;
        }

        try {
            const response = await axios.post(`${PTERODACTYL_PANEL_URL}/api/client/servers/${serverId}/command`, {
                command: commandToSend,
            }, {
                headers: {
                    'Authorization': `Bearer ${PTERODACTYL_API_KEY}`,
                    'Content-Type': 'application/json',
                    'Accept': 'Application/vnd.pterodactyl.v1+json',
                },
            });

            if (response.status === 204) {
                await interaction.reply({ content: "Command sent successfully!", ephemeral: true });
            } else {
                await interaction.reply({ content: "Failed to send the command.", ephemeral: true });
            }
        } catch (error) {
            console.error("Error sending command: ", error);
            await interaction.reply({ content: 'There was an error trying to execute that command!', ephemeral: true });
        }
    }
};