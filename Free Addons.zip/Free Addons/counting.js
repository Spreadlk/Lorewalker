const mongoose = require('mongoose');
const math = require('mathjs');

const COUNTING_CHANNEL_ID = '1240794511765012582';


const gameStateSchema = new mongoose.Schema({
    currentCount: { type: Number, default: 1 },
    lastUserId: { type: String, default: null }
});


const GameState = mongoose.model('GameState', gameStateSchema);

module.exports.run = async (client) => {
    let gameState = await GameState.findOne();
    if (!gameState) {
        gameState = new GameState();
        await gameState.save();
    }

    client.on('messageCreate', async message => {
        if (message.author.bot || message.channel.id !== COUNTING_CHANNEL_ID) return;

        try {
            const expression = message.content.replace(/ln/g, 'log');
            const userNumber = math.evaluate(expression);


            if (Number.isInteger(userNumber)) {

                if (message.author.id === gameState.lastUserId) {
                    return;
                }

                if (userNumber === gameState.currentCount) {
                    gameState.lastUserId = message.author.id;
                    gameState.currentCount++;
                    await message.react('✅');
                    await gameState.save();
                } else {
                    await message.react('❌');
                    message.channel.send(`The next number is 1.`);
                    resetCount();
                }
            } else {
            }
        } catch (error) {
            console.log(`Error evaluating expression: ${error.message}`);
        }
    });

    async function resetCount() {
        gameState.currentCount = 1;
        gameState.lastUserId = null;
        await gameState.save();
        console.log(`Count reset to 1`);
    }

    console.log("Counting game addon is loaded and ready!");
};