const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');

// Define reminders map outside the execute function
const reminders = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reminder')
        .setDescription('Create a reminder.')
        .addStringOption(option => option.setName('time').setDescription('Time for the reminder (10s, 1m, 1h)').setRequired(true))
        .addStringOption(option => option.setName('message').setDescription('Message').setRequired(true)),
    async execute(interaction) {
        const time = interaction.options.getString('time');
        const reminderMessage = interaction.options.getString('message');

        const timeInSeconds = parseTimeToSeconds(time);

        if (isNaN(timeInSeconds) || timeInSeconds <= 0) {
            return interaction.reply('Format invalid, exemple corecte: (1s, 1h, 10m).');
        }

        const reminderTime = Date.now() + timeInSeconds * 1000;

        // Use the reminders map defined outside the execute function
        reminders.set(interaction.user.id, {
            time: reminderTime,
            message: reminderMessage,
        });

        setTimeout(() => {
            const storedReminder = reminders.get(interaction.user.id);
            if (storedReminder) {
                const embed = new EmbedBuilder()
                    .setColor('#9b00ff')
                    .setTitle('REMINDER')
                    .setDescription(storedReminder.message);
                embed.setFooter({
                		text: 'Reminder | Stellar Bot', 
                		iconURL: 'https://imgur.com/1AGZlhf.gif',
            });

                interaction.user.send({ embeds: [embed] });
                reminders.delete(interaction.user.id);
            }
        }, timeInSeconds * 1000);

        const replyEmbed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('REMINDER SET')
            .setDescription(`I will remind you in ${time} with the following message: "${reminderMessage}"`)
            .setFooter({
                text: 'Reminder | Stellar Bot', 
                iconURL: 'https://imgur.com/1AGZlhf.gif',
            });

        interaction.reply({ embeds: [replyEmbed], ephemeral: true });
    },
};

function parseTimeToSeconds(time) {
    const regex = /(\d+)([smh])/;
    const match = time.match(regex);

    if (!match) return NaN;

    const value = parseInt(match[1]);
    const unit = match[2];

    switch (unit) {
        case 's':
            return value;
        case 'm':
            return value * 60;
        case 'h':
            return value * 60 * 60;
        default:
            return NaN;
    }
}
