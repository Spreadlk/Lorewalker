const fs = require("fs");
const yaml = require("js-yaml");
const config = yaml.load(fs.readFileSync("./addons/Drako-GPT/Drako-GPT.yml", "utf8"));
const OpenAI = require("openai");
const chatHistory = {};
const openAIConfig = {
  apiKey: config.ChatGPTAPI_KEY
};
const openAIInstance = new OpenAI(openAIConfig);

module.exports.run = async client => {
  client.on("messageCreate", async message => {
    try {
      if (message.author.bot || !message.mentions.users.has(client.user.id)) {
        return;
      }
      message.content = message.content.replace(/<@\d+>/g, "");
      const messageText = message.content;
      const authorId = message.author.id;

      if (!chatHistory[authorId]) {
        chatHistory[authorId] = [];
      }

      const messageEntry = {
        role: "user",
        content: messageText
      };

      chatHistory[authorId].push(messageEntry);
      if (chatHistory[authorId].length > 30) {
        chatHistory[authorId].shift();
      }

      await message.channel.sendTyping();
      const chatRequest = {
        model: config.GPT_Model,
        messages: chatHistory[authorId],
        temperature: 0,
        max_tokens: 1024
      };

      const response = await openAIInstance.chat.completions.create(chatRequest);
      if (response.choices && response.choices.length > 0) {
        const replyContent = response.choices[0].message.content;
        await message.reply(`<@${authorId}> ${replyContent}`);
      } else {
        console.log("Generated reply is empty or response structure is unexpected.");
      }
    } catch (error) {
      console.error("An error occurred:", error.message);
    }
  });
};
